import geopandas
import pandas as pd
import matplotlib.pyplot as plt
import descartes
import geopandas as gpd
from shapely.geometry import Point, Polygon
from sklearn.cluster import DBSCAN
from sklearn import metrics
from sklearn.datasets import make_blobs
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import NearestNeighbors
import numpy as np
import random
#from geopy.geocoders import Nominatim




# USER INPUT
city_name = "Seattle"
# or try:
#city_name = "Chicago"
#city_name = "Miami"





df = pd.read_csv('./data_files/gun-violence-data_01-2013_03-2018.csv')
# set CooRdinate System for latitude / longitude
my_crs = "EPSG:4326"

my_map = gpd.read_file('./map_files/' + city_name + '_Streets.shp')


# grab cities, lat, long
city_df = df.loc[(df["city_or_county"] == city_name), ["latitude", "longitude"]]

# TODO: Are these locations in the actual city. verify
lat_sum = city_df['latitude'].sum()
long_sum = city_df['longitude'].sum()
lat_count = np.count_nonzero(city_df['latitude'])
long_count = np.count_nonzero(city_df['longitude'])

lat_avg = lat_sum / lat_count
long_avg = long_sum / long_count


#city_df.drop(city_df.loc[(city_df['latitude'] > lat_avg + 3) | (city_df['latitude'] < lat_avg - 3) | (city_df['longitude'] > long_avg + 3) | (city_df['longitude'] < long_avg - 3)].index, inplace =True)

#city_df.dropna(inplace = True)

# list of points, long/ lat order matters
city_geometry = geopandas.points_from_xy(city_df.longitude, city_df.latitude)
   # [Point(xy) for xy in zip( city_df["longitude"], city_df["latitude"])]

geo_df = gpd.GeoDataFrame(city_df, crs = my_crs, geometry = city_geometry)

fig,ax = plt.subplots(figsize = (40,40))
my_map.plot(ax = ax, alpha = 0.4, color = "grey")
geo_df.plot(ax = ax, markersize = 15, color = "red", marker = "o")

plt.savefig("./outputs/" + city_name)

# find most common location and count number of incdences
most_common_locs = city_df.groupby(['latitude', 'longitude']).size().sort_values(ascending=False)
# Seattle is not accuratly reporting locations of violent gun crimes
# data say 88 shootings occured at sea-tac from 2013-2018!

# find city with highest number of incidents
cities_by_num = df.groupby('city_or_county').size().sort_values(ascending=False)
# 1. Chicago: 11k,  2. Baltimore: 4k


# START of DBSCAN
# get array of lat and longs
del city_df['geometry']
xy_norm = city_df.to_numpy()
# standardize
sc = StandardScaler()
xy_norm = sc.fit_transform(xy_norm)
# get rid of nans
xy_norm = xy_norm[~np.isnan(xy_norm).any(axis=1)]
# get 4th farthest neighbor distance for each point,
#   4 comes from oginal DBSCAN paper, 4 is best for all 2-d data (cite)
nbrs = NearestNeighbors(n_neighbors=5).fit(xy_norm)
distances, indices = nbrs.kneighbors(xy_norm)

dist_4th = np.delete(distances, [0, 1, 2, 3], 1)
# not sure why it doesnt want to sort
#dist_4th_df = pd.DataFrame(dist_4th, columns=['4-dist'])
#dist_4th_df.sort_values('4-dist', ascending=False)

dist_4th_list = dist_4th.tolist()
dist_4th_list.sort(reverse=True)
dist_4th_arr = np.array(dist_4th_list)

x = np.arange(0, len(dist_4th_list))
y = dist_4th_arr[x]
#plt.title("Radius Threshold:" + city_name)
#plt.xlabel("points")
#plt.ylabel("4-dist")
#plt.plot(x,y,"ob")
# this graph section needs work
#plt.show()
#plt.savefig("./outputs/" + city_name + "RadiusGraph")




# find good radius from 4-dist without graph, so it can be automated
radius = .1
min_neighbors = 4

db = DBSCAN(eps= radius, min_samples=4).fit(xy_norm)
core_samples_mask = np.zeros_like(db.labels_, dtype=bool)
core_samples_mask[db.core_sample_indices_] = True
labels = db.labels_

# number of clusters in labels
n_clusters_ = len(set(labels)) - (1 if -1 in labels else 0)
n_noise_ = list(labels).count(-1)

# plot those clusters
# drop nans
geo_df.dropna(inplace = True)
geo_df["label"] = labels.tolist()
plt.clf()

# get random colors
n_colors = n_clusters_
hexadecimal_alphabets = '0123456789ABCDEF'
color = ["#" + ''.join([random.choice(hexadecimal_alphabets) for j in
range(6)]) for i in range(n_colors)]


city_geometry = geopandas.points_from_xy(geo_df.longitude, geo_df.latitude)

geo_df = gpd.GeoDataFrame(geo_df, crs = my_crs, geometry = city_geometry)

fig1,ax1 = plt.subplots(figsize = (40,40))
my_map.plot(ax = ax1, alpha = 0.4, color = "grey")
geo_df[geo_df['label']==-1].plot(ax = ax1, markersize = 15, color = "black", marker = "o", label = "outlier")
for n in range(n_colors):
    geo_df[geo_df['label'] == n].plot(ax=ax1, markersize=15, color=color[n], marker="o", label=n+1)
ax1.legend(prop={'size':15})

plt.savefig("./outputs/" + city_name + "Results")






print()

